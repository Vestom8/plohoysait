-- VulnShop DB backup (автоматический, забыли удалить)
INSERT INTO users (username, password, email, role) VALUES ('admin', 'admin123', 'admin@vulnshop.local', 'admin');
-- DB_ROOT_PASSWORD=root:P@ssw0rd!
